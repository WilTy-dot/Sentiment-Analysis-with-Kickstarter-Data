

### Course: Text Analysis
### Lecturer: Dr. Jochen Hartmann
### Assignment: "Predicting online success from text data"


### Data Source: https://www.pnas.org/doi/10.1073/pnas.2026045118 
### Reference: Markowitz, D. M., & Shulman, H. C. (2021). The predictive utility of word familiarity for online engagements and funding. Proceedings of the National Academy of Sciences, 118(18).
### Please see the ReadMe file for variable descriptions: https://osf.io/rym7z/


# check and set working directory
getwd()
setwd("")

# set random seed to make results replicable
set.seed(42)

# load libraries
library(dplyr)
library(stargazer)
library(car)
library(anytime)
library(tm)

# load data
d <- read.csv("kickstarter_data_OSF_simplified.csv", stringsAsFactors = F)
#load("kickstarter_data_OSF_simplified.Rda")  # alternative option to import the data

# explore data
head(d, 3)
View(d[1:10,])
length(unique(d$country))  # check number of countries
sort(table(d$category), decreasing = T)  # check distribution of categories

# transform variables
d <- d %>% rename(text = blurb)  # rename text column
summary(d$WC)
d$WC_mc <- as.numeric(scale(d$WC, scale = F))  # mean-center word count (WC)
summary(d$WC_mc)  # check mean-centering
d$campaign_success <- ifelse(d$state == "failed", 0, 1)
d$usd_pledged_ln <- log(d$usd_pledged + 1)
d$goal_ln <- log(d$goal + 1)
d$backers_count_ln <- log(d$backers_count+1)
d$start_year <- format(as.Date(anytime(d$unix_startdate), format="%d/%m/%Y"),"%Y")

# create additional text-based variables
d$i <- grepl("\\bi\\b|\\bme\\b|\\bmyself\\b|\\bmy\\b", tolower(d$text))  # helpful resource for regex: https://cran.r-project.org/web/packages/stringr/vignettes/regular-expressions.html
round(prop.table(table(d$i)), 3)  # explore new variable
d %>% group_by(i) %>% summarize(usd_pledged_mean = mean(usd_pledged))  # explore model-free evidence
d %>% 
  filter(i == T) %>% select(text) %>% sample_n(5)

# visualize data
plot(table(d$start_year), main = "Number of Projects over Time")  # plot distribution of years
par(mfrow = c(1,2))
hist(d$usd_pledged_ln, main = "Amount Pledged (in USD, ln)")
hist(d$goal_ln, main = "Funding Goal (in USD, ln)")
round(cor(d$usd_pledged_ln, d$goal_ln), 3)  # check correlation
hist(d$WC, main = "Word Count")
hist(d$WC_mc, main = "Word Count (mean-centered)")

# sample data (optional)
if(FALSE){d <- d %>% sample_n(10000)}

# apply text classifier to full data, important: run "SentimentML_Script.R" before running this
corpus2 <- VCorpus(VectorSource(d$text))
dtm2 <- DocumentTermMatrix(corpus2, control = list(dictionary = Terms(dtm_unigram), 
                                                   weighting = function(x) weightBin(x)))  
dtm2  # inspect document-term-matrix (number of columns should be identical to the document-term-matrix based on which the classifier is trained)
d$sentiment <- predict(model_dt, as.data.frame(as.matrix(dtm2)), type = "class")  # create new column based on predictions from classifier
table(d$sentiment)  # important: this is a weak sentiment measure and just for illustration purposes

# analyze data
m <- list()
m[[1]] <- glm(campaign_success ~ WC_mc+ i + goal_ln + date_difference + country + category, data = d, family = "binomial")  # logistic regression (for binary data)
m[[2]] <- lm(usd_pledged_ln ~ WC_mc+ i + goal_ln + date_difference + country + category, data = d)  # linear regression (for continuous data)
m[[3]] <- update(m[[2]], "usd_pledged ~ .")  # change to non-ln transformed usd_pledged to compare model fit
m[[4]] <- update(m[[2]], "backers_count_ln ~ .")
m[[5]] <- glm(backers_count ~ WC_mc + i + goal_ln + date_difference + country + category, data = d, family = "poisson")  # poisson regression (for count data)
summary(m[[1]])
vif(m[[1]])  # check vif values
     
# report results
stargazer(m,
          title = "Regression Results",
          omit = c("country", "category"),
          no.space = F,
          initial.zero = F,
          notes.align = "l",
          notes = "",
          star.cutoffs = c(.05, .01, .001),
          add.lines=list(c('Country Fixed Effects', rep('Yes', length(m))),
                         c('Category Fixed Effects', rep('Yes', length(m)))),
          omit.stat = "aic",
          type = "text")

# plot curves in relevant value range
par(mfrow = c(1,3))
START = quantile(d$WC_mc, probs = .05, na.rm = T)  # define 90% value range for WC from START to END
START
END = quantile(d$WC_mc, probs = .95, na.rm = T)
END

# plot campaign success
b1 = coef(m[[1]])["WC_mc"]
c = coef(m[[1]])["(Intercept)"]
curve(b1 * x + c, from = START, to = END, 
      ylab="Campaign Success", xlab = "Word Count (mean-centered)")

# plot usd pledged (ln)
b1 = coef(m[[2]])["WC_mc"]
c = coef(m[[2]])["(Intercept)"]
curve(b1 * x + c, from = START, to = END, 
      ylab="USD Pledged (ln)", xlab = "Word Count (mean-centered)")

# plot backers count
b1 = coef(m[[5]])["WC_mc"]
c = coef(m[[5]])["(Intercept)"]
curve(b1 * x + c, from = START, to = END, 
      ylab="Backers Count", xlab = "Word Count (mean-centered)")

# THE END